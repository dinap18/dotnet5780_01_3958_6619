﻿using System;
enum Choice { reserve=0, calender, daysTaken, exit };
namespace part2
{

    class Program
    {
        static void Main(string[] args)
        {
            bool[,] reservations = new bool[12, 31];
            for (int i = 0; i < 12; i++)
                for (int j = 0; j < 31; j++)
                    reservations[i, j] = false;
            string Choice;
            bool flag = false;
            int startDate=0, length=0, startMonth;
            Console.WriteLine("Enter your choice:");
            Choice = Console.ReadLine();
            int choice,counter=0,helper=0;
            choice = Convert.ToInt32(Choice);
            do
            {
                switch (choice)
                {
                    case 0://reserve
                        Console.WriteLine("enter the day of the month your stay will start");
                        startDate = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter the month your stay will take place in");
                        startMonth = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter how long your stay will be");
                        length = Convert.ToInt32(Console.ReadLine());
                        if (startDate > 31 || startMonth > 12 || startDate < 1 || startMonth < 1)
                            break;
                               if(reservations[startMonth,startDate]==false)
                                {
                                    for (int k = 0; k < length; k++)
                                    {
                                if (startDate < 31 && reservations[startMonth, ++startDate] == true)
                                {
                                    Console.WriteLine("sorry,those dates are taken");
                                    break;
                                  
                                }
                                else
                                    if (startDate == 31 && reservations[++startMonth, startDate = 0] == true)
                                {
                                    Console.WriteLine("sorry,those dates are taken");
                                    break;
                                 
                                }
                                else flag = true;
                                    }
                                }
                        if(flag==true)
                        {
                            counter += length;
                         
                            for (int i = startMonth; i <12; i++)
                                for (int j = startDate; j < 31; j++)
                                {
                                    if (helper <= length)
                                    {
                                        reservations[i, j] = true;
                                        helper++;
                                    }
                                    else
                                        break;
                                }
                            helper = 0;
                        }
                        break;
                    case 1://print
                        for (int i = 0; i < 12; i++)
                            for (int j = 0; j < 31; j++)
                            {
                                if (reservations[i, j] == true)
                                    Console.Write(Convert.ToString(i)+"/"+ Convert.ToString(j-length) +"  ");
                                if (reservations[i, j] == true && j < 30 && reservations[i, ++j] == false)
                                {
                                    Console.WriteLine();
                                    
                                }

                                else
                                    if (reservations[i, j] == true && j == 31 && reservations[++i, j = 0] == false)
                                {
                                    Console.WriteLine();
                                    j--;
                                }
                                
                            }
                        break;
                    case 2://stats
                        Console.WriteLine(counter + "   days of the year taken");
                        Console.WriteLine((counter/372 ) + "  percent of year taken");
                        break;
                    case 3:
                        break;
                    default:
                        Console.WriteLine("ERROR");
                        break;
                }
                Console.WriteLine("Enter your choice:");
                Choice = Console.ReadLine();
                choice = Convert.ToInt32(Choice);
            } while (choice != 3);
            Console.ReadKey();
        }
    }
}
